from setuptools import find_packages, setup

setup(
    name='transcribeauto',
    packages=find_packages(),
    version='0.1.0',
    description='Transcribe any video!',
    author='Devesh Paragiri',
    license='MIT',
    install_requires=[],

)